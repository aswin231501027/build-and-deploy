# BDML Mini Project - Heart Disease Prediction

## Overview
This project predicts the likelihood of heart disease using Machine Learning.  
It is a **Flask-based web application** that allows users to enter health parameters  
and get instant predictions.

## Technologies Used
- Python  
- Flask  
- Scikit-learn  
- HTML, CSS  
- Docker (for containerization)

## Model Details
The model was trained on a heart disease dataset with features like:
- Age  
- Sex  
- Cholesterol  
- Blood Pressure  
- Max Heart Rate, etc.

Trained model and dataset are excluded due to file size limits,  
but can be easily retrained using the included code.

## Docker Usage
Docker is used to package the application into a single container,  
so it runs consistently on any system.

### Build the Docker Image
```bash
docker build -t heart-predictor .
docker run -p 5000:5000 heart-predictor
